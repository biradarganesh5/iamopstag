"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.handler = exports.default = void 0;
var _aws_cloud_trail_event_listener = _interopRequireDefault(require("./aws_cloud_trail_event_listener.js"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
if (!global._babelPolyfill) {
  require('babel-polyfill'); // eslint-disable-line global-require
}
const handler = async (cloudtrailEvent, context) => {
  const enabledListeners = [_aws_cloud_trail_event_listener.default.EC2.name, _aws_cloud_trail_event_listener.default.S3.name, _aws_cloud_trail_event_listener.default.AUTOSCALE_GROUPS.name, _aws_cloud_trail_event_listener.default.VPC.name, _aws_cloud_trail_event_listener.default.SUBNETS.name, _aws_cloud_trail_event_listener.default.ELB.name, _aws_cloud_trail_event_listener.default.EBS.name, _aws_cloud_trail_event_listener.default.INTERNET_GATEWAY.name, _aws_cloud_trail_event_listener.default.RDS.name, _aws_cloud_trail_event_listener.default.EMR.name, _aws_cloud_trail_event_listener.default.DATA_PIPELINE.name, _aws_cloud_trail_event_listener.default.SECURITY_GROUP.name, _aws_cloud_trail_event_listener.default.AMI_CREATE.name, _aws_cloud_trail_event_listener.default.AMI_COPY.name, _aws_cloud_trail_event_listener.default.AMI_REGISTER.name, _aws_cloud_trail_event_listener.default.SNAPSHOT_CREATE.name, _aws_cloud_trail_event_listener.default.SNAPSHOT_COPY.name, _aws_cloud_trail_event_listener.default.SNAPSHOT_IMPORT.name, _aws_cloud_trail_event_listener.default.ELASTIC_IP.name, _aws_cloud_trail_event_listener.default.DYNAMO_DB.name, _aws_cloud_trail_event_listener.default.ENI.name, _aws_cloud_trail_event_listener.default.NAT_GATEWAY.name, _aws_cloud_trail_event_listener.default.NETWORK_ACL.name, _aws_cloud_trail_event_listener.default.ROUTE_TABLE.name, _aws_cloud_trail_event_listener.default.VPC_PEERING.name, _aws_cloud_trail_event_listener.default.VPN_CONNECTION.name, _aws_cloud_trail_event_listener.default.VPN_GATEWAY.name, _aws_cloud_trail_event_listener.default.OPS_WORKS.name, _aws_cloud_trail_event_listener.default.OPS_WORKS_CLONE.name, _aws_cloud_trail_event_listener.default.IAM_USER.name, _aws_cloud_trail_event_listener.default.IAM_ROLE.name, _aws_cloud_trail_event_listener.default.CUSTOMER_GATEWAY.name, _aws_cloud_trail_event_listener.default.DHCP_OPTIONS.name, _aws_cloud_trail_event_listener.default.LAMBDA_FUNCTION_2015.name, _aws_cloud_trail_event_listener.default.LAMBDA_FUNCTION_2014.name, _aws_cloud_trail_event_listener.default.CLOUDWATCH_ALARM.name, _aws_cloud_trail_event_listener.default.CLOUDWATCH_EVENTS_RULE.name, _aws_cloud_trail_event_listener.default.CLOUDWATCH_LOG_GROUP.name];
  const listener = new _aws_cloud_trail_event_listener.default(cloudtrailEvent, context, enabledListeners);
  await listener.execute();
};
exports.handler = handler;
var _default = exports.default = handler;