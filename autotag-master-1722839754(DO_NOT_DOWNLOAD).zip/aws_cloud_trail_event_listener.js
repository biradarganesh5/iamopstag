"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _each = _interopRequireDefault(require("lodash/each.js"));
var _cloud_trail_event_config = _interopRequireDefault(require("./cloud_trail_event_config.js"));
var _autotag_factory = _interopRequireDefault(require("./autotag_factory.js"));
var _autotag_settings = _interopRequireDefault(require("./autotag_settings.js"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
class AwsCloudTrailEventListener {
  constructor(cloudtrailEvent, applicationContext, enabledServices) {
    if (cloudtrailEvent.Records) {
      this.cloudtrailEvent = JSON.parse(cloudtrailEvent.Records[0].Sns.Message);
    } else {
      this.cloudtrailEvent = cloudtrailEvent;
    }
    this.applicationContext = applicationContext;
    this.enabledServices = enabledServices;
  }
  async execute() {
    try {
      const event = this.cloudtrailEvent.detail;
      // inject this field into the cloudwatch rule event to make it uniform with the S3 file event
      // this field was the only field that was moved from the "detail" sub-hash up into the top level
      event.recipientAccountId = this.cloudtrailEvent.account;
      if (!event.errorCode && !event.errorMessage) {
        const worker = _autotag_factory.default.createWorker(event, this.enabledServices, this.cloudtrailEvent.region);
        await worker.tagResource();
        this.logDebug();
      } else {
        this.logEventError(event);
      }
      this.applicationContext.succeed();
    } catch (e) {
      this.handleError(e);
    }
  }
  handleError(err) {
    if (_autotag_settings.default.DebugLoggingOnFailure) {
      console.log(`CloudTrail Event - Failed: ${JSON.stringify(this.cloudtrailEvent, null, 2)}`);
    }
    console.log(err);
    console.log(err.stack);
    this.applicationContext.fail(err);
  }
  logDebug() {
    if (_autotag_settings.default.DebugLogging) {
      console.log(`CloudTrail Event - Debug: ${JSON.stringify(this.cloudtrailEvent, null, 2)}`);
    }
  }
  logEventError(event) {
    if (event.errorCode) {
      console.log(`CloudTrail Event - Error Code: ${event.errorCode}`);
    }
    if (event.errorMessage) {
      console.log(`CloudTrail Event - Error Message: ${event.errorMessage}`);
    }
  }
}
(0, _each.default)(_cloud_trail_event_config.default, (value, key) => {
  AwsCloudTrailEventListener[key] = value;
});
var _default = exports.default = AwsCloudTrailEventListener;