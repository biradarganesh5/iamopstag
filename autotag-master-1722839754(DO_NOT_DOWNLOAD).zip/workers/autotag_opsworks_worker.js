"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clientOpsworks = require("@aws-sdk/client-opsworks");
var _autotag_default_worker = _interopRequireDefault(require("./autotag_default_worker.js"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
class AutotagOpsworksWorker extends _autotag_default_worker.default {
  /* tagResource
  ** method: tagResource
  **
  ** Add tag to OpsWorks stack
  */

  async tagResource() {
    const roleName = this.roleName;
    const credentials = await this.assumeRole(roleName);
    this.opsworks = new _clientOpsworks.OpsWorks({
      region: this.event.awsRegion,
      credentials
    });
    const opsworksStacks = await this.getOpsworksStacks();
    const opsworksStackArn = this.getOpsworksStackArn(opsworksStacks);
    await this.tagOpsworksStack(opsworksStackArn);
  }
  tagOpsworksStack(opsworksStackArn) {
    return new Promise((resolve, reject) => {
      try {
        const tagConfig = this.getOpsworksTags(this.getAutotagTags());
        this.logTags(opsworksStackArn, tagConfig, this.constructor.name);
        this.opsworks.tagResource({
          ResourceArn: opsworksStackArn,
          Tags: tagConfig
        }, err => {
          if (err) {
            reject(err);
          } else {
            resolve(true);
          }
        });
      } catch (e) {
        reject(e);
      }
    });
  }
  getOpsworksStackArn(opsworksStacks) {
    const opsworksStack = opsworksStacks.Stacks.find(stack => stack.Name === this.event.requestParameters.name);
    if (opsworksStack) {
      return opsworksStack.Arn;
    } else {
      throw Error(`Error: No OpsWorks Stacks found when searching for '${this.event.requestParameters.name}' by name.`);
    }
  }
  getOpsworksStacks() {
    return new Promise((resolve, reject) => {
      try {
        this.opsworks.describeStacks({}, (err, res) => {
          if (err) {
            reject(err);
          } else {
            resolve(res);
          }
        });
      } catch (e) {
        reject(e);
      }
    });
  }
  getOpsworksTags(tagConfig) {
    const tags = {};
    tagConfig.forEach(tag => {
      // exclude the 'create time' and the 'invoked by' tags
      // otherwise OpsWorks will propagate it to the instances
      if (![this.getCreateTimeTagName(), this.getInvokedByTagName()].includes(tag.Key)) {
        tags[tag.Key] = tag.Value;
      }
    });
    return tags;
  }
}
var _default = exports.default = AutotagOpsworksWorker;