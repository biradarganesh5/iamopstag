"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clientS = require("@aws-sdk/client-s3");
var _autotag_default_worker = _interopRequireWildcard(require("./autotag_default_worker.js"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
class AutotagS3Worker extends _autotag_default_worker.default {
  /* tagResource
  ** method: tagResource
  **
  ** Tag the S3 bucket with the relevant information
  */

  async tagResource() {
    const roleName = this.roleName;
    const credentials = await this.assumeRole(roleName);
    this.s3 = new _clientS.S3({
      region: this.event.awsRegion,
      credentials
    });
    let tags = await this.getExistingTags();
    // remove anything starting with the prefix before we add our tags to make this idempotent
    tags = tags.filter(tag => !tag.Key.startsWith(_autotag_default_worker.AUTOTAG_TAG_NAME_PREFIX));
    tags = tags.concat(this.getAutotagTags());
    await this.setTags(tags);
  }
  getExistingTags() {
    return new Promise((resolve, reject) => {
      try {
        this.s3.getBucketTagging({
          Bucket: this.getBucketName()
        }, (err, res) => {
          if (err) {
            if (err.Code === 'NoSuchTagSet') {
              resolve([]);
            } else {
              reject(err);
            }
          } else {
            resolve(res.TagSet);
          }
        });
      } catch (e) {
        reject(e);
      }
    });
  }
  setTags(tags) {
    return new Promise((resolve, reject) => {
      try {
        const bucketName = this.getBucketName();
        this.logTags(bucketName, tags, this.constructor.name);
        this.s3.putBucketTagging({
          Bucket: bucketName,
          Tagging: {
            TagSet: tags
          }
        }, (err, res) => {
          if (err) {
            reject(err);
          } else {
            resolve(res);
          }
        });
      } catch (e) {
        reject(e);
      }
    });
  }
  getBucketName() {
    return this.event.requestParameters.bucketName;
  }
}
var _default = exports.default = AutotagS3Worker;