"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clientEc = require("@aws-sdk/client-ec2");
var _autotag_ec2_worker = _interopRequireDefault(require("./autotag_ec2_worker.js"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
class AutotagRouteTableWorker extends _autotag_ec2_worker.default {
  /* tagResource
  ** method: tagResource
  **
  ** Tag the newly created RouteTable
  */

  async tagResource() {
    const roleName = this.roleName;
    const credentials = await this.assumeRole(roleName);
    this.ec2 = new _clientEc.EC2({
      region: this.event.awsRegion,
      credentials
    });
    await this.tagEC2Resources([this.getRouteTableId()]);
  }
  getRouteTableId() {
    return this.event.responseElements.routeTable.routeTableId;
  }
}
var _default = exports.default = AutotagRouteTableWorker;