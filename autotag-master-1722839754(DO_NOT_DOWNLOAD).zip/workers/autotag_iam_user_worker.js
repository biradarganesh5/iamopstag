"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clientIam = require("@aws-sdk/client-iam");
var _autotag_default_worker = _interopRequireDefault(require("./autotag_default_worker.js"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
class AutotagIAMUserWorker extends _autotag_default_worker.default {
  /* tagResource
  ** method: tagResource
  **
  ** Tag the newly created IAM User
  */

  async tagResource() {
    const roleName = this.roleName;
    const credentials = await this.assumeRole(roleName);
    this.iam = new _clientIam.IAM({
      region: this.event.awsRegion,
      credentials
    });
    await this.tagIamUserResource();
  }
  tagIamUserResource() {
    return new Promise((resolve, reject) => {
      try {
        const userName = this.getUserName();
        const tags = this.getAutotagTags();
        this.logTags(userName, tags, this.constructor.name);
        this.iam.tagUser({
          UserName: userName,
          Tags: tags
        }, err => {
          if (err) {
            reject(err);
          } else {
            resolve(true);
          }
        });
      } catch (e) {
        reject(e);
      }
    });
  }
  getUserName() {
    return this.event.responseElements.user.userName;
  }
}
var _default = exports.default = AutotagIAMUserWorker;