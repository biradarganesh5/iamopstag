"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clientCloudwatchLogs = require("@aws-sdk/client-cloudwatch-logs");
var _autotag_default_worker = _interopRequireDefault(require("./autotag_default_worker.js"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
class AutotagCloudwatchLogGroupWorker extends _autotag_default_worker.default {
  /* tagResource
  ** method: tagResource
  **
  ** Tag the newly created Log Group
  */

  async tagResource() {
    const roleName = this.roleName;
    const credentials = await this.assumeRole(roleName);
    this.cloudwatchLogs = new _clientCloudwatchLogs.CloudWatchLogs({
      region: this.event.awsRegion,
      credentials
    });
    await this.tagLogGroupResource();
  }
  tagLogGroupResource() {
    return new Promise((resolve, reject) => {
      try {
        const logGroupName = this.getLogGroupName();
        const tags = this.getFunctionTags(this.getAutotagTags());
        this.logTags(logGroupName, tags, this.constructor.name);
        this.cloudwatchLogs.tagLogGroup({
          logGroupName,
          tags
        }, err => {
          if (err) {
            reject(err);
          } else {
            resolve(true);
          }
        });
      } catch (e) {
        reject(e);
      }
    });
  }
  getFunctionTags(tags) {
    const newTags = {};
    tags.forEach(tag => {
      newTags[tag.Key] = tag.Value;
    });
    return newTags;
  }
  getLogGroupName() {
    return this.event.requestParameters.logGroupName;
  }
}
var _default = exports.default = AutotagCloudwatchLogGroupWorker;