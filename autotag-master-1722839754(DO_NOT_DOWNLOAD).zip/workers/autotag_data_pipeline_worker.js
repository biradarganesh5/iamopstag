"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clientDataPipeline = require("@aws-sdk/client-data-pipeline");
var _autotag_default_worker = _interopRequireDefault(require("./autotag_default_worker.js"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
class AutotagDataPipelineWorker extends _autotag_default_worker.default {
  /* tagResource
  ** method: tagResource
  **
  ** Tag DataPipeline and associated resources
  */

  async tagResource() {
    const roleName = this.roleName;
    const credentials = await this.assumeRole(roleName);
    this.dataPipeline = new _clientDataPipeline.DataPipeline({
      region: this.event.awsRegion,
      credentials
    });
    await this.tagDataPipelineResource();
  }
  tagDataPipelineResource() {
    return new Promise((resolve, reject) => {
      try {
        const dataPipelineId = this.getDataPipelineId();
        const tags = this.getAutotagTags();
        this.logTags(dataPipelineId, tags, this.constructor.name);
        this.dataPipeline.addTags({
          pipelineId: dataPipelineId,
          tags
        }, err => {
          if (err) {
            reject(err);
          } else {
            resolve(true);
          }
        });
      } catch (e) {
        reject(e);
      }
    });
  }
  getDataPipelineId() {
    return this.event.responseElements.pipelineId;
  }

  // datapipeline will only accept lower case key names
  getAutotagTags() {
    const tags = [];
    super.getAutotagTags().forEach(val => {
      const tag = {
        key: val.Key,
        value: val.Value
      };
      tags.push(tag);
    });
    return tags;
  }
}
var _default = exports.default = AutotagDataPipelineWorker;