"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _find = _interopRequireDefault(require("lodash/find.js"));
var _values = _interopRequireDefault(require("lodash/values.js"));
var _autotag_default_worker = _interopRequireDefault(require("./workers/autotag_default_worker.js"));
var _autotag_ec2_worker = _interopRequireDefault(require("./workers/autotag_ec2_worker.js"));
var _autotag_s3_worker = _interopRequireDefault(require("./workers/autotag_s3_worker.js"));
var _autotag_elb_worker = _interopRequireDefault(require("./workers/autotag_elb_worker.js"));
var _autotag_ebs_worker = _interopRequireDefault(require("./workers/autotag_ebs_worker.js"));
var _autotag_autoscale_worker = _interopRequireDefault(require("./workers/autotag_autoscale_worker.js"));
var _autotag_vpc_worker = _interopRequireDefault(require("./workers/autotag_vpc_worker.js"));
var _autotag_subnet_worker = _interopRequireDefault(require("./workers/autotag_subnet_worker.js"));
var _autotag_internet_gateway_worker = _interopRequireDefault(require("./workers/autotag_internet_gateway_worker.js"));
var _autotag_rds_worker = _interopRequireDefault(require("./workers/autotag_rds_worker.js"));
var _autotag_emr_worker = _interopRequireDefault(require("./workers/autotag_emr_worker.js"));
var _autotag_data_pipeline_worker = _interopRequireDefault(require("./workers/autotag_data_pipeline_worker.js"));
var _autotag_security_group_worker = _interopRequireDefault(require("./workers/autotag_security_group_worker.js"));
var _autotag_ami_worker = _interopRequireDefault(require("./workers/autotag_ami_worker.js"));
var _autotag_snapshot_worker = _interopRequireDefault(require("./workers/autotag_snapshot_worker.js"));
var _autotag_eip_worker = _interopRequireDefault(require("./workers/autotag_eip_worker.js"));
var _autotag_dynamodb_worker = _interopRequireDefault(require("./workers/autotag_dynamodb_worker.js"));
var _autotag_eni_worker = _interopRequireDefault(require("./workers/autotag_eni_worker.js"));
var _autotag_nat_gateway_worker = _interopRequireDefault(require("./workers/autotag_nat_gateway_worker.js"));
var _autotag_network_acl_worker = _interopRequireDefault(require("./workers/autotag_network_acl_worker.js"));
var _autotag_route_table_worker = _interopRequireDefault(require("./workers/autotag_route_table_worker.js"));
var _autotag_vpc_peering_worker = _interopRequireDefault(require("./workers/autotag_vpc_peering_worker.js"));
var _autotag_vpn_connection_worker = _interopRequireDefault(require("./workers/autotag_vpn_connection_worker.js"));
var _autotag_vpn_gateway_worker = _interopRequireDefault(require("./workers/autotag_vpn_gateway_worker.js"));
var _autotag_opsworks_worker = _interopRequireDefault(require("./workers/autotag_opsworks_worker.js"));
var _autotag_iam_user_worker = _interopRequireDefault(require("./workers/autotag_iam_user_worker.js"));
var _autotag_iam_role_worker = _interopRequireDefault(require("./workers/autotag_iam_role_worker.js"));
var _autotag_customer_gateway_worker = _interopRequireDefault(require("./workers/autotag_customer_gateway_worker.js"));
var _autotag_dhcp_options_worker = _interopRequireDefault(require("./workers/autotag_dhcp_options_worker.js"));
var _autotag_lambda_function_worker = _interopRequireDefault(require("./workers/autotag_lambda_function_worker.js"));
var _autotag_cw_alarm_worker = _interopRequireDefault(require("./workers/autotag_cw_alarm_worker.js"));
var _autotag_cw_events_rule_worker = _interopRequireDefault(require("./workers/autotag_cw_events_rule_worker.js"));
var _autotag_cw_loggroup_worker = _interopRequireDefault(require("./workers/autotag_cw_loggroup_worker.js"));
var _cloud_trail_event_config = _interopRequireDefault(require("./cloud_trail_event_config.js"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const AutotagFactory = {
  createWorker: (event, enabledServices, s3Region) => {
    // Match Service
    const matchingService = (0, _find.default)((0, _values.default)(_cloud_trail_event_config.default), {
      targetEventName: event.eventName
    });

    // Check service found and service enabled
    if (typeof matchingService === 'undefined' || enabledServices.indexOf(matchingService.name) < 0) {
      // Default: worker that does nothing
      return new _autotag_default_worker.default(event, s3Region);
    }

    // Select the relevant worker
    switch (matchingService.name) {
      case _cloud_trail_event_config.default.EC2.name:
        return new _autotag_ec2_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.S3.name:
        return new _autotag_s3_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.ELB.name:
        return new _autotag_elb_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.AUTOSCALE_GROUPS.name:
        return new _autotag_autoscale_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.VPC.name:
        return new _autotag_vpc_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.SUBNETS.name:
        return new _autotag_subnet_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.EBS.name:
        return new _autotag_ebs_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.INTERNET_GATEWAY.name:
        return new _autotag_internet_gateway_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.RDS.name:
        return new _autotag_rds_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.EMR.name:
        return new _autotag_emr_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.DATA_PIPELINE.name:
        return new _autotag_data_pipeline_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.SECURITY_GROUP.name:
        return new _autotag_security_group_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.AMI_CREATE.name:
        return new _autotag_ami_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.AMI_COPY.name:
        return new _autotag_ami_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.AMI_REGISTER.name:
        return new _autotag_ami_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.SNAPSHOT_CREATE.name:
        return new _autotag_snapshot_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.SNAPSHOT_COPY.name:
        return new _autotag_snapshot_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.SNAPSHOT_IMPORT.name:
        return new _autotag_snapshot_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.ELASTIC_IP.name:
        return new _autotag_eip_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.DYNAMO_DB.name:
        return new _autotag_dynamodb_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.ENI.name:
        return new _autotag_eni_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.NAT_GATEWAY.name:
        return new _autotag_nat_gateway_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.NETWORK_ACL.name:
        return new _autotag_network_acl_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.ROUTE_TABLE.name:
        return new _autotag_route_table_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.VPC_PEERING.name:
        return new _autotag_vpc_peering_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.VPN_CONNECTION.name:
        return new _autotag_vpn_connection_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.VPN_GATEWAY.name:
        return new _autotag_vpn_gateway_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.OPS_WORKS.name:
        return new _autotag_opsworks_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.OPS_WORKS_CLONE.name:
        return new _autotag_opsworks_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.IAM_USER.name:
        return new _autotag_iam_user_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.IAM_ROLE.name:
        return new _autotag_iam_role_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.CUSTOMER_GATEWAY.name:
        return new _autotag_customer_gateway_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.DHCP_OPTIONS.name:
        return new _autotag_dhcp_options_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.LAMBDA_FUNCTION_2015.name:
        return new _autotag_lambda_function_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.LAMBDA_FUNCTION_2014.name:
        return new _autotag_lambda_function_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.CLOUDWATCH_ALARM.name:
        return new _autotag_cw_alarm_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.CLOUDWATCH_EVENTS_RULE.name:
        return new _autotag_cw_events_rule_worker.default(event, s3Region);
      case _cloud_trail_event_config.default.CLOUDWATCH_LOG_GROUP.name:
        return new _autotag_cw_loggroup_worker.default(event, s3Region);

      // Default: worker that does nothing
      default:
        return new _autotag_default_worker.default(event, s3Region);
    }
  }
};
var _default = exports.default = AutotagFactory;